package edu.rit.croatia.swen383.g2.ws.sensor;
public enum SensorType {
  TEMPERATURE, PRESSURE
}
