package edu.rit.croatia.swen383.g2.ws.observer;

public interface Observer {
  void update();
}
